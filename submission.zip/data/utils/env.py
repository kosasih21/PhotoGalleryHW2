# IAM User access configuration
AWS_ACCESS_KEY="AKIAVVZOOIY2XIDUCW6M"
AWS_SECRET_ACCESS_KEY="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"
AWS_REGION="us-east-1"

# S3 Bucket for photo objects
PHOTOGALLERY_S3_BUCKET_NAME="photobuckethw2-kosasih-2025"

# MySQL Configuration
RDS_DB_HOSTNAME= 'photogallerydb.cnqimiuu6cze.us-east-1.rds.amazonaws.com'
RDS_DB_USERNAME='root'
RDS_DB_PASSWORD='CloudComputing2025'
RDS_DB_NAME='photogallerydb'

# DynamoDB Table
DYNAMODB_TABLE='photogallerydb' #Use PhotoGallery if you were following video walkthrough

###### INSERT NEW ENVIRONMENT VARIABLES HERE ######


####################################################
